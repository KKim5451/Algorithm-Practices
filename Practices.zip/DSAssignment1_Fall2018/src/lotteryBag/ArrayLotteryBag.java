package lotteryBag;

import java.util.Arrays;

/**
 * Assignment 1, Fall 2018 UNC Charlotte ITIS 2214 Data Structures and
 * Algorithms
 *
 * @author clatulip
 * @param <E> extends Comparable E extends 
 * to the comparable methods and implements LotteryBagADT
 * @version 1.0
 */
public class ArrayLotteryBag<E extends Comparable> implements LotteryBagADT<E> {

    private E[] bag;
    private int numE;
    /**
     * Class ArrayLotteryBag, a array version of Lottery Bag
     */
    public ArrayLotteryBag() {
        bag = (E[]) (new Comparable[10]);
        numE = 0;
    }

    /**
     * If the bag is at capacity run expandCapacity Adds an element to the bag
     * Increment numE
     *
     * @param element target number
     */
    @Override
    public void add(E element) {
        if (numE == bag.length) {
            expandCapacity();
        }
        bag[numE] = element;
        numE++;
    }
    /**
     * Selects a random element from the collection and returns it
     *
     * @return E
     * @throws EmptyCollectionException if the bag is empty
     */
    @Override
    public E remove() throws EmptyCollectionException {
        if (numE == 0)
        {
            throw new EmptyCollectionException("Lottery Bag Empty!");
        }
        E temp = this.bag[this.numE - 1];
        bag[numE - 1] = null;
        this.numE--;
        return temp;
        //To change body of generated methods, choose Tools | Templates.
    }
    /**
     * Iterates through the collection and returns true if the passed in element
     * exists in the collection If the entire collection is checked and the
     * element is not found then return false
     *
     * @param target - element to be searched for
     * @return boolean - whether or not the target was found
     * @throws EmptyCollectionException if the bag is empty
     */
    @Override
    public boolean contains(E target) throws EmptyCollectionException {
        if (numE == 0) {
            throw new EmptyCollectionException("Lottery Bag Empty!");
        }
        for (int i = 0; i < numE; i++)
        {
            if (bag[i].compareTo(target) == 0)
            {
                return true;
            }
        }
        return false;
    }
    /**
     * Checks to see if the size is empty
     * @return numE value
     */
    @Override
    public boolean isEmpty() {
        return numE == 0;
    }
    /**
     * Checks for the size of the array
     * @return numE for the value
     */
    @Override
    public int size() {
        return numE;
    }
    /**
     * Makes a string format
     * @return s for the string
     */
    @Override
    public String toString() {
        String s = "LotteryBag: \n";
        for (int i = 0; i < numE; i++) {
            s = s.concat("\t" + bag[i].toString() + "\n");
        }
        return s;
    }

    /**
     * Remove 3 elements from the collection Determine which of the 3 elements
     * is the largest using compareTo Put the two smaller elements back in the
     * collection Return the largest element
     *
     * @return E
     * @throws EmptyCollectionException if it has less than 3 elements
     */
    public E pick3() throws EmptyCollectionException {

        if (this.size() < 3) {
            throw new EmptyCollectionException(
                    "pick3 has less than 3 elements");
        }

        E highElement = null;
        E e1 = this.remove();
        E e2 = this.remove();
        E e3 = this.remove();

        // compare elements removed
        // largest is stored in highElement
        if (e1.compareTo(e2) == 1) {
            highElement = e1;
            if (e3.compareTo(e1) == 1) {
                highElement = e3;
            }
        } 
        else 
        {
            if (e2.compareTo(e3) == 1) {
                highElement = e2;
            } 
            else 
            {
                highElement = e3;
            }
        }

        // Removed elements that are not the highest 
        //are added back into the collection
        // Return highest value ticket
        if (!highElement.equals(e1)) {
            this.add(e1);
        }
        if (!highElement.equals(e2)) {
            this.add(e2);
        }
        if (!highElement.equals(e3)) {
            this.add(e3);
        }
        
        return highElement;

    }
    /**
     * expands the capacity of the array
     */
    private void expandCapacity() {
        bag = Arrays.copyOf(bag, bag.length * 2);
    }

}
