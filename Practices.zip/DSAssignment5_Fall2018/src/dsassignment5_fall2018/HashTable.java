/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment5_fall2018;

import ADTs.*;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * @version Fall2018
 * @author clatulip
 * @param <T> generic with key value
 */
public class HashTable<T extends Hashable> implements HashTableADT {

    private static final int DEFAULT_INIT_SIZE = 100;
    private ArrayList<LinkedList<Hashable>> table;
    private int numSlots; // number of slots in table
    private int size; // number of items stored

    /**
     * Default constructor Sets table numSlots to default
     */
    public HashTable() {
        table = new ArrayList<>(DEFAULT_INIT_SIZE);
        // initialize hash table by creating each LinkedList
        for (int i = 0; i < DEFAULT_INIT_SIZE; i++) {
            table.add(new LinkedList<>());
        }
        this.numSlots = DEFAULT_INIT_SIZE;
        size = 0;
    }

    /**
     * Constructor that allows the user to specify table numSlots
     *
     * @param numSlots number of slots in the table
     */
    public HashTable(int numSlots) {

        table = new ArrayList<>(numSlots);
        // initialize hash table by creating each LinkedList
        for (int i = 0; i < numSlots; i++) {
            table.add(new LinkedList<>());
        }
        this.numSlots = numSlots;
        this.size = 0;
    }

    /**
     * Chain of values that hash to the same index
     *
     * @param key index of table to check
     * @return LinkedList of values at an index
     */
    public LinkedList<Hashable> getChain(int key) {
        // the linkedlist required is at the key position of the table
        LinkedList<Hashable> result = table.get(key);
        return result;
    }

    @Override
    public void clear() {
        table = new ArrayList<>(numSlots);
        // initialize hash table by creating each LinkedList
        for (int i = 0; i < numSlots; i++) {
            table.add(new LinkedList<>());
        }
        this.size = 0;
    }

    @Override
    public boolean containsKey(int key) {
        // get the chain
        LinkedList<Hashable> chain = table.get(key % numSlots);
        // search through chain for a key
        for (int i = 0; i < chain.size(); i++) {
            if (chain.get(i).getHashKey() == key) {
                // found it! 
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean containsValue(Hashable value) {
        // the hashed value
        int key = value.getHashKey();
        // the right chain
        LinkedList<Hashable> chain = table.get(key % numSlots); 
        for (int i = 0; i < chain.size(); i++) {
            // the right value
            if (chain.contains(value)) {
                return true;                // found it! 
            }
        }
        return false;                       // not found! 
            
    }

    @Override
    public void put(int key, Hashable value) {
        LinkedList<Hashable> chain = table.get(key % numSlots);
        chain.addFirst(value);
        size++;
    }

    @Override
    public boolean remove(Hashable value) {
        // the hashed value
        int key = value.getHashKey();
        // the right chain
        LinkedList<Hashable> chain = table.get(key % numSlots); 
        for (int i = 0; i < chain.size(); i++) {
            // the right value
            if (chain.contains(value)) {     
                // remove this value
                chain.remove(value);
                // reduce the size
                this.size--;
                return true;
            }
        }
        return false;
        
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    /**
     * Total slots available to store elements
     *
     * @return total number of slots in the table
     */
    public int getTableSize() {
        return numSlots;
    }

    /**
     * Searches the table and checks the length of each chain
     *
     * @return longest chain length
     */
    public int longestChainLength() {
        // initial smallest size 0
        int tempSize = 0;
        int i = 0;
        for (i = 0; i < this.numSlots; i++) {
            // replace with the large one
            if (this.table.get(i).size() > tempSize) { 
                tempSize = this.table.get(i).size();
            }
        }
        return tempSize;
    }

    /**
     * Searches the table and counts any slot that contains no elements
     *
     * @return total number of indices with no elements stored
     */
    public int emptySlots() {
        // assume no empty slot
        int count = 0;
        int i = 0;
        for (i = 0; i < this.numSlots; i++) {
            // replace with the large one
            if (this.table.get(i).isEmpty()) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Return the average length chain in the table (excluding empty chains)
     * Remove the number of empty slots from the total numSlots of the table
     * Number of elements stored in the table / number of slots with elements
     * stored
     *
     * @return average length of a chain
     */
    public float averageChainLength() {
        // initial length 0
        float totalLength = 0.0f;
        int i = 0;
        // accumulate the size of chains in the loop
        for (i = 0; i < this.numSlots; i++) {
            totalLength += this.table.get(i).size();
        }
        return totalLength / this.numSlots;
    }

    /**
     * How full is the table?
     *
     * @return total number of slots filled / number of items stored
     */
    public float load() {
        // assume 0 slots filled
        float numFilledSlots = 0.0f;
        // assume 0 items initially
        int numItems = 0;
        int i = 0;
        // accumulate the items and increase num filled slots in the loop
        for (i = 0; i < this.numSlots; i++) {
            numItems += this.table.get(i).size();
            if (!this.table.get(i).isEmpty()) {
                numFilledSlots += 1;
            }
        }
        
        return numFilledSlots / numItems;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Printing out hash table:\n");
        for (int i = 0; i < table.size(); i++) {
            sb.append("Chain at index ").append(String.format("%2d", i)).append(": [");
            for (int j = 0; j < this.getChain(i).size(); j++) {
                sb.append(this.getChain(i).get(j).toString());
            }
            sb.append("]\n");
        }

        sb.append("\nTable Stats\n");
        sb.append("-----------\n");
        sb.append("      Slots: ").append(numSlots).append("\n");
        sb.append("       Size: ").append(size).append("\n");
        sb.append("Empty Slots: ").append(this.emptySlots()).append("\n");

        return sb.toString();
    }
}
