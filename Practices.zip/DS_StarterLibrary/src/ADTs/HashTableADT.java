/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADTs;

import Exceptions.ElementNotFoundException;

/**
 * @param <T>
 * @author clatulip
 * @version Fall2018
 */
public interface HashTableADT<T extends Hashable> extends CollectionADT {

    /**
     * Removes all elements from the table
     * Must clear each slot in the table individually to clear the chains
     */
    public void clear();

    /**
     * Checks that a key is being used in the table
     * Go to the slot in the HashTable and iterate through the chain to find the key
     *
     * @param key to be checked
     * @return true if the key is in use
     */
    public boolean containsKey(int key);

    /**
     * Checks that a particular value is stored
     * Go to the slot in the HashTable and iterate through the chain to find the key
     *
     * @param value to be checked
     * @return true if the value is in the table
     */
    public boolean containsValue(T value);

    /**
     * Places a value in the table
     *
     * @param key hash code of the value to be stored
     * @param value to be stored
     */
    public void put(int key, T value);

    /**
     * @param value to be removed
     * @return element
     */
    public boolean remove(T value);
}
