/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment5_fall2018;

import java.util.Calendar;
import ADTs.*;

/**
 * @version Fall2018
 * @author clatulip
 */
public class ConcertTicket implements Hashable {

    private String name;
    private Calendar date;
    private int price;

    /**
     * Default constructor
     */
    public ConcertTicket() {
        name = "No name";
        date = Calendar.getInstance();
        date.set(Calendar.DAY_OF_YEAR, (int) (Math.random() * 365));
        price = (int) (Math.random() * 100);
    }

    /**
     * Alternate constructor
     *
     * @param name of concert
     * @param date concert will be held
     * @param price of ticket
     */
    public ConcertTicket(String name, Calendar date, int price) {
        this.name = name;
        this.date = date;
        this.price = price;
    }

    /**
     * @return name of concert
     */
    public String getName() {
        return name;
    }

    /**
     * @param name of concert
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return date of concert
     */
    public Calendar getDate() {
        return date;
    }

    /**
     * @param date of concert
     */
    public void setDate(Calendar date) {
        this.date = date;
    }

    /**
     * @return ticket price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price of ticket
     */
    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object ct) {
        if (ct == null) {
            return false;
        }
        if (ct == this) {
            return true;
        }
        if (!(ct instanceof ConcertTicket)) {
            return false;
        }
        ConcertTicket c = (ConcertTicket) ct;
        return (this.price == c.getPrice())
                && (this.name == null ? c.getName() == null : this.name.equals(c.getName()))
                && (this.date.get(Calendar.DAY_OF_YEAR)
                == c.getDate().get(Calendar.DAY_OF_YEAR));
    }

    @Override
    public String toString() {
        return "ConcertTicket{" + "name=" + name + ", price=" + price + ", on " 
                + date.get(Calendar.MONTH) + "/" + date.get(Calendar.DAY_OF_MONTH) + '}';
    }

    @Override
    public int getHashKey() {
        // We create a (hopefully) unique hash combining the ticket price and the date
        return price * 1541 
                + date.get(Calendar.DAY_OF_YEAR) 
                + date.get(Calendar.MONTH) 
                + date.get(Calendar.YEAR) 
                * (name.length() * 7);
    }

}
