/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment2_fall2018;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kevin Kim
 * @version 1.0
 */
public class ArrayListStackTest {

    /**
     * Test of push method, of class ArrayListStack.
     */
    @Test
    public void testPush() {
        System.out.println("testing push");
        ArrayListStack instance = new ArrayListStack();
        assertEquals(0, instance.size());
        instance.push("hello0");
        assertEquals(1, instance.size());
        instance.push("hello1");
        instance.push("hello2");
        assertEquals(3, instance.size());
    }

    /**
     * Test of pop method, of class ArrayListStack.
     */
    @Test
    public void testPop() throws Exception {
        System.out.println("testing pop");
        ArrayListStack instance = new ArrayListStack();
        assertEquals(0, instance.size());
        try
        {
            instance.pop();
        }
        catch (Exception e) {
            assertTrue(e instanceof Exception);
            System.out.println("expected exception.");
        }
        instance.push("hello0");
        assertEquals(1, instance.size());
        instance.pop();
    }

    /**
     * Test of peek method, of class ArrayListStack.
     */
    @Test
    public void testPeek() throws Exception {
        System.out.println("testing pop");
        ArrayListStack instance = new ArrayListStack();
        assertEquals(0, instance.size());
        try
        {
            instance.peek();
        }
        catch (Exception e) {
            assertTrue(e instanceof Exception);
            System.out.println("expected exception.");
        }
        instance.push("hello0");
        assertEquals(1, instance.size());
        instance.peek();
    }

    /**
     * Test of size method, of class ArrayListStack.
     */
    @Test
    public void testSize() {
        System.out.println("testing pop");
        ArrayListStack instance = new ArrayListStack();
        assertEquals(0, instance.size());
        instance.push("hello0");
        instance.push("hello1");
        assertEquals(2, instance.size());
    }

    /**
     * Test of isEmpty method, of class ArrayListStack.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("testing pop");
        ArrayListStack instance = new ArrayListStack();
        assertEquals(0, instance.size());
        assertTrue(instance.isEmpty());
    }

    /**
     * Test of toString method, of class ArrayListStack.
     */
    @Test
    public void testToString() {
        System.out.println("testing pop");
        ArrayListStack instance = new ArrayListStack();
        String letters = "";
        String result = instance.toString();
        assertNotEquals(letters, result);
    }

}
