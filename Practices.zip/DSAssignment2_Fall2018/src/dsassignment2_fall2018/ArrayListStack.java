/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment2_fall2018;

import Exceptions.EmptyCollectionException;
import java.util.ArrayList;
import ADTs.StackADT;

/**
 *
 * @author Kevin Kim
 * @version 1.0
 * @param <T> generic object created
 */
public class ArrayListStack<T> implements StackADT<T> {

    private ArrayList<T> stack;
    private int top = 0;

    /**
     * Adds the specified element to the top of the stack
     *
     */
    public ArrayListStack() {
        stack = new ArrayList<T>();
    }

    /**
     * adding an element to the stack
     *
     * @param element generic objected element
     */
    public void push(T element) {
        stack.add(element);
        top++;
    }

    /**
     * Removes and returns the element that is on top of the stack
     *
     * @return the element removed from the stack
     * @throws EmptyCollectionException when stack is empty
     */
    public T pop() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Stack is empty");
        }
        T temp = stack.remove(stack.size() - 1);
        return temp;
    }

    /**
     * Returns (without removing) the element that is on top of the stack
     *
     * @return the element on top of the stack
     * @throws EmptyCollectionException when stack is empty
     */
    public T peek() throws EmptyCollectionException {
        T temp = stack.get(stack.size() - 1);
        return temp;
    }

    /**
     * stack size
     *
     * @return top to keep track of stack size
     */
    public int size() {
        return top;
    }

    /**
     * if stack is empty
     *
     * @return true or false if stack is empty
     */
    public boolean isEmpty() {
        return top == 0;
    }

    /**
     * prints out as string
     *
     * @return string to print out
     */
    public String toString() {
        StringBuffer sb = new StringBuffer("");
        for (T element : stack) {
            if (element != null) {
                sb.append(element.toString());
                sb.append(", ");
            }
        }
        return "ArrayStack{" + sb + '}';
    }
}
