/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dslab_Searching;

/**
 *
 * @author clatulip
 */
public class ConcertTicket implements Comparable<ConcertTicket> {
    private String name;
    private int price;

    public ConcertTicket(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public ConcertTicket() {
        name = "";
        price = 0;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ConcertTicket{" + "name=" + name + ", price=" + price + '}';
    }

    @Override
    public int compareTo(ConcertTicket o) {
        return this.price - o.getPrice();
    }
    

}
