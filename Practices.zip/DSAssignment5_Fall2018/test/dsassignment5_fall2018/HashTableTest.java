/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment5_fall2018;

import java.util.Calendar;
import java.util.GregorianCalendar;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @version Fall2018
 * @author Kyle
 */
public class HashTableTest {
    private HashTable<ConcertTicket> instance;
    private final ConcertTicket a;
    private final ConcertTicket b;
    private final ConcertTicket c;
    private final ConcertTicket d;
    private final ConcertTicket e;
    private final ConcertTicket f;
    private final ConcertTicket g;
    private final ConcertTicket h;
    private final ConcertTicket i;
    private final ConcertTicket j;
    private final ConcertTicket k;
    private final ConcertTicket l;
    private final ConcertTicket m;
    private final ConcertTicket n;
    private final ConcertTicket o;
    private final ConcertTicket p;

    private final ConcertTicket q;

    /**
     * Initialize Instance and ConcertTickets ConcertTickets a - p will be in
     * the collection ConcertTicket q has not been added
     */
    public HashTableTest() {
        instance = new HashTable<ConcertTicket>(30);
        //Same hash value
        a = new ConcertTicket("a", new GregorianCalendar(2016, Calendar.JUNE, 11), 40);
        b = new ConcertTicket("b", new GregorianCalendar(2016, Calendar.JUNE, 11), 40);
        c = new ConcertTicket("c", new GregorianCalendar(2016, Calendar.JUNE, 11), 40);
        d = new ConcertTicket("d", new GregorianCalendar(2016, Calendar.JUNE, 11), 40);

        //Same hash value
        e = new ConcertTicket("e", new GregorianCalendar(2017, Calendar.JUNE, 20), 60);
        f = new ConcertTicket("f", new GregorianCalendar(2017, Calendar.JUNE, 20), 60);
        g = new ConcertTicket("g", new GregorianCalendar(2017, Calendar.JUNE, 20), 60);
        h = new ConcertTicket("h", new GregorianCalendar(2017, Calendar.JUNE, 20), 60);

        //Same hash value
        i = new ConcertTicket("i", new GregorianCalendar(2018, Calendar.JUNE, 30), 70);
        j = new ConcertTicket("j", new GregorianCalendar(2018, Calendar.JUNE, 30), 70);

        //Same hash value
        k = new ConcertTicket("k", new GregorianCalendar(2018, Calendar.JUNE, 9), 80);
        l = new ConcertTicket("l", new GregorianCalendar(2018, Calendar.JUNE, 9), 80);

        m = new ConcertTicket("m", new GregorianCalendar(990, Calendar.JUNE, 3), 401);
        n = new ConcertTicket("n", new GregorianCalendar(2040, Calendar.JUNE, 12), 2);
        o = new ConcertTicket("o", new GregorianCalendar(2019, Calendar.JUNE, 8), 120);
        p = new ConcertTicket("p", new GregorianCalendar(2020, Calendar.JUNE, 14), 100);

        //Not added to instance
        q = new ConcertTicket("q", new GregorianCalendar(0000, Calendar.JUNE, 1), 1);
    }

    /**
     * Put new ConcertTickets into instance
     */
    @Before
    public void setUp() {
        instance.put(a.getHashKey(), a);
        instance.put(b.getHashKey(), b);
        instance.put(c.getHashKey(), c);
        instance.put(d.getHashKey(), d);
        instance.put(e.getHashKey(), e);
        instance.put(f.getHashKey(), f);
        instance.put(g.getHashKey(), g);
        instance.put(h.getHashKey(), h);
        instance.put(i.getHashKey(), i);
        instance.put(j.getHashKey(), j);
        instance.put(k.getHashKey(), k);
        instance.put(l.getHashKey(), l);
        instance.put(m.getHashKey(), m);
        instance.put(n.getHashKey(), n);
        instance.put(o.getHashKey(), o);
        instance.put(p.getHashKey(), p);
    }

    /**
     * Test of getChain method, of class LinkedList.
     */
    @Test
    public void testGetChain() {
        
        // the first element of the chain from 10 and 17, matches m and o
        assertTrue(instance.getChain(10).get(0).equals(m));
        assertTrue(instance.getChain(17).get(0).equals(o));
    }

    /**
     * Test of clear method, of class HashTable.
     */
    @Test
    public void testClear() {
        System.out.println("clear");
        //Initial states
        assertEquals(instance.size(), 16);
        assertEquals(instance.getTableSize(), 30);
        assertTrue(instance.containsValue(a));

        //Run clear and test states again
        instance.clear();
        assertEquals(instance.size(), 0);
        assertFalse(instance.containsValue(a));
        assertEquals(instance.getTableSize(), 30);
    }

    /**
     * Test of containsKey method, of class HashTable.
     */
    @Test
    public void testContainsKey() {
        System.out.println("containsKey");
        
        // a, c are contained
        assertTrue(instance.containsKey(a.getHashKey()));
        assertTrue(instance.containsKey(c.getHashKey()));
    }

    /**
     * Test of containsValue method, of class HashTable.
     */
    @Test
    public void testContainsValue() {
        System.out.println("containsValue");

        //Positive test cases
        assertTrue(instance.containsValue(a));
        assertTrue(instance.containsValue(p));

        //Negative test case
        assertFalse(instance.containsValue(q));
    }

    /**
     * Test of put method, of class HashTable.
     */
    @Test
    public void testPut() {
        System.out.println("put");
        
        // inital state
        assertFalse(instance.containsValue(q));
        assertEquals(instance.size(), 16);
        
        // insert q
        instance.put(q.getHashKey(), q);
        
        // final state, +1 size, q present
        assertEquals(instance.size(), 17);
        assertTrue(instance.containsValue(q));
    }

    /**
     * Test of remove method, of class HashTable.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");

        //Initial states
        assertEquals(instance.size(), 16);
        assertEquals(instance.getTableSize(), 30);
        assertTrue(instance.containsValue(a));

        //Change table state
        assertTrue(instance.remove(a));

        //Retest states
        assertEquals(instance.size(), 15);
        assertEquals(instance.getTableSize(), 30);
        assertFalse(instance.containsValue(a));
    }

    /**
     * Test of isEmpty method, of class HashTable.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");

        //Initial state
        assertEquals(instance.size(), 16);
        assertEquals(instance.getTableSize(), 30);
        assertFalse(instance.isEmpty());

        instance = new HashTable<>();

        //Retest state
        assertTrue(instance.isEmpty());
    }

    /**
     * Test of size method, of class HashTable.
     */
    @Test
    public void testSize() {
        System.out.println("size");

        //Initial State
        assertEquals(instance.size(), 16);

        //Change State - Empty
        instance = new HashTable<>(30);
        assertEquals(instance.size(), 0);

        //Change State - 1
        instance.put(a.getHashKey(), a);
        assertEquals(instance.size(), 1);
    }

    /**
     * Test of getTableSize method, of class HashTable.
     */
    @Test
    public void testGetTableSize() {
        System.out.println("getTableSize");
        
        // table size, 30
        assertEquals(instance.getTableSize(), 30);
    }

    /**
     * Test of longestChainLength method, of class HashTable.
     */
    @Test
    public void testLongestChainLength() {
        System.out.println("longestChainLength");
        
        // longest chain counted, 4
        assertEquals(instance.longestChainLength(), 4);
    }

    /**
     * Test of emptySlots method, of class HashTable.
     */
    @Test
    public void testEmptySlots() {
        System.out.println("emptySlots");
        
        // number of empty slots, 23
        assertEquals(instance.emptySlots(), 23);
    }

    /**
     * Test of averageChainLength method, of class HashTable.
     */
    @Test
    public void testAverageChainLength() {
        System.out.println("averageChainLength");
        
        
        // averageChainLength with 0.1 accuracy
        assertEquals(instance.averageChainLength(), 0.53, 0.1);
    }

    /**
     * Test of load method, of class HashTable.
     */
    @Test
    public void testLoad() {
        System.out.println("load");
        
        // load fraction with 0.1 accuracy
        assertEquals(instance.load(), 7.0 / 16, 0.1);
        
    }

    /**
     * Test of toString method, of class HashTable.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        assertNotNull(instance.toString());
    }

}
