package dsassignment3_customer;

import ADTs.*;
import DataStructures.*;
import Exceptions.*;
import java.util.Random;

/**
 * This data structure is a special form of queue designed to handle Customers,
 * although it is capable of handling other comparable Objects as well.
 * Note that a typical queue does not use add/remove at an index methods.
 * 
 * @author Perrin Mele
 * @param <T>
 * @version v1.0
 */
public class CustomerServiceQueue<T extends Comparable<T>>
                                    implements QueueADT<T> {

    private LinearNode<T> front;
    private LinearNode<T> back;
    private int size;
    
    /**
     * Constructor for a new CustomerServiceQueue.
     */
    public CustomerServiceQueue() {
        front = back = null;
        size = 0;
    }

    /**
     *Adds an element to the back of the queue.
     * 
     * @param customer
     */
    @Override
    public void enqueue(T customer) {
        LinearNode<T> tempNode = new LinearNode<> (customer);
        if (back == null) {
            front = back = tempNode;
            size++;
            return ;
        }
        back.setNext(tempNode);
        tempNode.setNext(back);
        back = tempNode;
        back.setNext(null);
        size++;
    }
    
    /**
     * Removes an element from the front of the queue.
     * 
     * @return the removed element.
     * @throws EmptyCollectionException 
     */
    @Override
    public T dequeue() throws EmptyCollectionException { //Give actual
        if (size == 0) {
            throw new EmptyCollectionException("CustomerServiceQueue");
        }
        T removedElement = front.getElement();
        if (size == 1) {
            front = back = null;
            size--;
            return removedElement;
        }
        front = front.getNext();
        front.setPrev(null);
        size--;
        return removedElement;
    }
    
    /**
     * Looks at, but does not remove, the front element in the queue.
     * 
     * @return the front element.
     * @throws EmptyCollectionException 
     */
    @Override
    public T first() throws EmptyCollectionException {
        if (front == null) {
            throw new EmptyCollectionException("Empty!");
        }
        T frontElement = front.getElement();
        return frontElement;
    }
    
    /**
     * 
     * @return the size of the queue.
     */
    @Override
    public int size() {
        return size;
    }
    
    /**
     * 
     * @return whether or not the queue is empty.
     */
    @Override
    public boolean isEmpty() {
        return (front == null);
    }
    
    /**
     * This method has a 50% chance of removing (true)
     * and a 50% chance of removing but re-adding to the back (false).
     * It represents whether or not a Customer was successfully
     * helped - if not, they get back in line.
     * 
     * @return a boolean representing if the element was completely removed.
     * @throws EmptyCollectionException 
     */
    public boolean help() throws EmptyCollectionException {
        //Chance of returning to back of queue
        Random rand = new Random();
        if (rand.nextInt(2) == 0) { //Helped successfully
            this.dequeue();
            return true;
        } else { //Helped unsuccessfully, had to get back in line
            this.enqueue(this.dequeue());
            return false;
        }
    }

    /**
     * Pushes relevant elements forward 1 in the queue.
     * Relevant elements include any who are considered by the
     * compareTo method to be equivalent to the parameter element.
     * A Customer object is considered equal to another
     * when they share the same issue.
     * 
     * @param elem value of the generic
     * @throws EmptyCollectionException 
     */
    public void increasePriority(T elem) throws EmptyCollectionException {
        if (size == 0) {
            throw new EmptyCollectionException("CustomerServiceQueue");
        }
        LinearNode<T> current = front;
        for (int x = 0; x < size; x++) {
            if (current.getElement().compareTo(elem) == 0 
                                && current.getPrev() != null) {
                //Takes the element out
                T temp = this.remove(x);
                //Replaces the element one spot closer to the front.
                this.add(x - 1, temp);
            }
            current = current.getNext();
        }
    }
    
    /**
     * Inserts an element at a given index.
     * 
     * @param index int value of the index
     * @param elem  value of the generic
     */
    public void add(int index, T elem) throws IndexOutOfBoundsException {
        /*
        This method needs to insert an element (elem) at an index (index).
        In order to do this, several steps must be taken,
        and several edge cases considered.
        
        Before even beginning to implement the method, let's consider what
        are applicable indices to pass in. Because this is an insertion, the
        number of viable locations is not equal to the number of elements in
        the queue, but rather the number of spaces before and after them.
        Check the index to make sure it makes sense. If not, throw exception.
        
        First, we must contain this new element the same way other
        elements in our data structure are contained.
        
        Then, we must cycle through our existing queue to find the spot
        at which our new container must be placed. While cycling, we should
        keep a reference pointing at the current node being viewed. When
        the cycling is over, this pointer will be used to access that node's
        methods without having to cycle again.
        
        Finally, we need to update the node of our element and its
        surrounding nodes so that they point to each other correctly.
        Remember that each node has both a previous and next reference,
        accessible using getPrev and getNext, changable using setters.
        
        An edge case may be that there is no element (or container thereof)
        to be found before the spot to be inserted at. This happens at index 0,
        which would place an elem at the front of the queue. 
        This is not the only edge case.
        
        Remember that because an element is added, size must increment!
        */
        if (size == 0 || index > size) {
            throw new IndexOutOfBoundsException("Size is 0");
        }
        LinearNode<T> tempNode = new LinearNode<> (elem);
        if (index == 0 || back == null) {
            front = back = tempNode;
            tempNode.setPrev(null);
            tempNode.setNext(null);
            size++;
            return;
        }
        
        if (index == size) {
            back.setNext(tempNode);
            tempNode.setPrev(back);
            back = tempNode;
            back.setNext(null);
            size++;
            return;
        }
        
        int whileCount = 0;
        LinearNode<T> prev = front;
        while (whileCount < index - 1) {
            prev = prev.getNext();
            whileCount++;
        }
        LinearNode<T> next;
        next = prev.getNext();
        tempNode.setNext(prev.getNext());
        tempNode.setPrev(next);
        prev.setNext(tempNode);
        size++;
    }
    
    /**
     * Removes an element from a given index.
     * 
     * @param index given value
     * @return T a removed value
     * @throws EmptyCollectionException
     * @throws IndexOutOfBoundsException 
     */
    public T remove(int index)
            throws EmptyCollectionException, IndexOutOfBoundsException {
        /*
        This method needs to remove an element (elem) at an index (index).
        Just like in the add method, several steps must be taken,
        and several edge cases considered.
        
        Once again, consider what indices are appropriate to allow here.
        In remove, do the indices represent the places between nodes,
        or do they represent the nodes themselves?
        
        We'll need to cycle through the queue until we reach the place
        represented by our index. Once there, we need to pull the element
        to be returned out, and save it to a temporary variable to return later.
        Again, a pointer referring to the current node is necessary.
        
        Finally, we need to remove pointers to the node of the removed element,
        and rearrange those pointers so that the queue remains intact. We can
        access the nodes surrounding the node being removed by using the
        getters. Note that the removed node's own pointers don't need to change,
        since as soon as nothing points to it, it and all its pointers will be
        discarded by java's garbage collection. Fun fact: An Object that nothing
        points to is called an orphan.
        
        An edge case may be that there is no element (or container thereof)
        to be found before the node being removed. This happens at index 0,
        which would remove the front element. Since removing the front element
        is what a queue is normally supposed to do, what can you call to make
        handling this edge case easier?
        This is not the only edge case.
        
        Remember that because an element is removed, size must decrement!
        */
        int whileCounter = 0;
        T tempGeneric;
        LinearNode<T> prev = front;
        LinearNode<T> prevNode;
        LinearNode<T> next;
        if (size <= 0) {
            dequeue();
        }
        if (index == (size - 1)) {
            tempGeneric = back.getElement();
            back = back.getPrev();
            back.setNext(null);
            size--;
            return tempGeneric;
        }
        while (whileCounter < index - 1) {
            prev = prev.getNext();
            whileCounter++;
        }
        prevNode = prev;
        prev.getNext();
        tempGeneric = prev.getElement();
        next = prev.getNext();
        prev.setNext(next);
        next.setPrev(prevNode);
        size--;
        return tempGeneric;
    }
    
    /**
     * Returns a String representing the queue and each of its elements.
     * 
     * @return 
     */
    @Override
    public String toString() {
        if (this.isEmpty()) {
            return "There is no one in line!";
        }
        String str = "Currently in line: ";
        LinearNode<T> current = front;
        for (int i = 0; i < size; i++) {
            str += "\n" + current.getElement().toString();
            current = current.getNext();
        }
        return str;
    }
}
