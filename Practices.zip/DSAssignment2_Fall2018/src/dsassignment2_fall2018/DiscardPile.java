/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment2_fall2018;

import ADTs.StackADT;
import Exceptions.*;

/**
 * This is a class that works with Cards A discard pile works as a standard
 * stack, you can add a card to the top look at the card on the top and take the
 * card on the top This class requires that you pass into the constructors a
 * stack of cards to operate on. The stack must adhere to StackADT.
 *
 * @author clatulip
 * @version 1.0
 */
public class DiscardPile {

    private StackADT<Card> pile;
    private int top;

    /**
     * Constructor - pass in an initialized stack data structure
     *
     * @param stack must be an object from a class that implements StackADT
     */
    public DiscardPile(StackADT stack) {
        pile = stack;
    }

    /**
     * Add a card to the pile
     *
     * @param c Card
     */
    public void addCard(Card c) {
        pile.push(c);
        top++;
    }

    /**
     * Removes and returns the top card from the pile
     *
     * @return Card on top of the pile
     * @throws EmptyCollectionException when stack is empty
     */
    public Card takeCard() throws EmptyCollectionException {
        if (pile.isEmpty()) {
            throw new EmptyCollectionException("Stack is empty");
        }
        Card temp = pile.pop();
        top--;
        return temp;
    }

    /**
     * Return (without removing) the card on top of the pile for inspection
     *
     * @return Card on top of the pile
     * @throws EmptyCollectionException when stack is empty
     */
    public Card look() throws EmptyCollectionException {
        Card temp = pile.peek();
        return temp;
    }

    /**
     * Find out if the pile has cards
     *
     * @return true if there are no cards, false otherwise
     */
    public boolean isEmpty() {
        return top == 0;
    }

    /**
     * Find out how many cards are on the discard pile
     *
     * @return int number of cards in the pile
     */
    

    public int size() {
        return top;
    }
}
