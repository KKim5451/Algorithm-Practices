
package lotteryBag;

import org.junit.Test;
import static org.junit.Assert.*;


/**
 * Data Structures & Algorithms Class
 * Assignment 1, Fall 2018
 * Testing harness for ArrayLotteryBag class
 * @author clatulip, <Kevin Kim> 
 * @version 1.0
 */
public class ArrayLotteryBagTest {
    

    /**
     * Test of add method, of class ArrayLotteryBag.
     */
    @Test
    public void testAdd() {
        System.out.println("testing add");
        //compare num to bag size
        ArrayLotteryBag<LotteryTicket> 
                instance = new ArrayLotteryBag<>();
        // lottery bag should initially be empty
        assertEquals(0, instance.size());
        assertTrue(instance.isEmpty());
        //add LotteryTicket
        instance.add(new LotteryTicket(500, "lotto"));
        // after adding, size should be incremented
        assertEquals(1, instance.size());
        assertFalse(instance.isEmpty());
        // add another
        instance.add(new LotteryTicket(2500, "lotto"));
        // after adding, size should be incremented
        assertEquals(2, instance.size());
        assertFalse(instance.isEmpty());
        for (int i = 0; i < 10; i++)
        {
            instance.add(new LotteryTicket(50, "hi"));
        }
        assertEquals(12, instance.size());
    }

    /**
     * Test of remove method, of class ArrayLotteryBag.
     */
    @Test
    public void testRemove() throws Exception {
        System.out.println("testing remove");
        ArrayLotteryBag<LotteryTicket> instance = new ArrayLotteryBag<>();
        // lottery bag should initially be empty
        assertEquals(0, instance.size());
        assertTrue(instance.isEmpty());
        // if we try to remove from an empty lottery bag, 
        //assertNull(instance.remove());
        try
        {
            instance.remove();
        }
        catch (Exception e) {
            assertTrue(e instanceof EmptyCollectionException);
            System.out.println("expected exception.");
        }
        
        // add a few items
        instance.add(new LotteryTicket(500, "lotto"));
        instance.add(new LotteryTicket(0, "sorry"));
        // now size should be 2
        assertEquals(2, instance.size());
        
        // now try to remove an item, result should not be null
        assertNotNull(instance.remove());
        
        // after removing, size should be decremented
        assertEquals(1, instance.size());
        assertFalse(instance.isEmpty());
        
        // remove another 
        assertNotNull(instance.remove());
        // after removing last item, size should be 0
        assertEquals(0, instance.size());
        assertTrue(instance.isEmpty());
        
    }

    /**
     * Test of contains method, of class ArrayLotteryBag.
     */
    @Test
    public void testContains() throws Exception {
        System.out.println("testing add");
        ArrayLotteryBag<LotteryTicket> 
                instance = new ArrayLotteryBag<>();

        // lottery bag should initially be empty
        assertEquals(0, instance.size()); // TRUE
        assertTrue(instance.isEmpty());
        
        try
        {
            instance.contains(new LotteryTicket(50, "hi"));
        }
        catch (Exception e) {
            assertTrue(e instanceof EmptyCollectionException);
            System.out.println("expected exception.");
        }

        // add a few items
        instance.add(new LotteryTicket(500, "lotto")); // 0th element
        instance.add(new LotteryTicket(0, "sorry"));
        //putting values for LotteryTicket
        LotteryTicket t1 = new LotteryTicket(500, "lotto");
        //check  to see if the lottery is the same
        assertTrue(instance.contains(t1));
        
        try
        {
            instance.contains(new LotteryTicket(10, "bye"));
        }
        catch (Exception e) {
            assertFalse(e instanceof EmptyCollectionException);
            System.out.println("expected exception.");
        }
    }

    /**
     * Test of isEmpty method, of class ArrayLotteryBag.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("testing isEmpty");
        ArrayLotteryBag<LotteryTicket> 
                instance = new ArrayLotteryBag<>();
        // lottery bag should initially be empty
        assertEquals(0, instance.size());
        assertTrue(instance.isEmpty());
    }

    /**
     * Test of size method, of class ArrayLotteryBag.
     */
    @Test
    public void testSize() {
        System.out.println("testing size");
        ArrayLotteryBag<LotteryTicket> instance = new ArrayLotteryBag<>();
        // lottery bag should initially be empty
        assertEquals(0, instance.size());
        
        // add a few items
        instance.add(new LotteryTicket(500, "lotto"));
        instance.add(new LotteryTicket(0, "sorry"));
        // now size should be 2
        assertEquals(2, instance.size());

    }


    /**
     * Test of pick3 method, of class ArrayLotteryBag.
     */
    @Test
    public void testPick3() throws Exception {
        System.out.println("testing pick3");
        ArrayLotteryBag<LotteryTicket> 
                instance = new ArrayLotteryBag<>();
        // lottery bag should initially be empty
        assertEquals(0, instance.size()); // TRUE
        assertTrue(instance.isEmpty());
        
        try
        {
            instance.pick3();
        }
        catch (Exception e) {
            assertTrue(e instanceof EmptyCollectionException);
            System.out.println("expected exception.");
        }
        
        LotteryTicket highestTicket = new LotteryTicket(1000, "hi");
        
        instance.add(new LotteryTicket(500, "lotto"));
        instance.add(new LotteryTicket(0, "sorry"));
        instance.add(highestTicket);
        //test exception
        assertEquals(3, instance.size());
        for (int i = 0; i < 20; i++)
        {
            assertEquals(0, instance.pick3().compareTo(highestTicket));
            instance.add(highestTicket);
        }

    }
}
