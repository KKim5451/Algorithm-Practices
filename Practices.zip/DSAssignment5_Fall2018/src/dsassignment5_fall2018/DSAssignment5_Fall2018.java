/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsassignment5_fall2018;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @version Fall2018
 * @author clatulip
 */
public class DSAssignment5_Fall2018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //<editor-fold defaultstate="collapsed" desc="Tickets">
        ArrayList<ConcertTicket> tickets = new ArrayList<ConcertTicket>() {
            {
                add(new ConcertTicket("Run The Jewels",
                        new GregorianCalendar(2018, Calendar.OCTOBER, 11), 49));
                add(new ConcertTicket("Kenny Chesney",
                        new GregorianCalendar(2018, Calendar.AUGUST, 11), 443));
                add(new ConcertTicket("Thomas Rhett",
                        new GregorianCalendar(2018, Calendar.DECEMBER, 11), 20));
                add(new ConcertTicket("Parmalee",
                        new GregorianCalendar(2018, Calendar.JULY, 11), 70));
                add(new ConcertTicket("Luke Combs",
                        new GregorianCalendar(2018, Calendar.JUNE, 11), 30));
                add(new ConcertTicket("Darius Rucker",
                        new GregorianCalendar(2018, Calendar.SEPTEMBER, 11), 50));
                add(new ConcertTicket("Queen",
                        new GregorianCalendar(1986, Calendar.JANUARY, 11), 120));
                add(new ConcertTicket("Jimmy Hendrix",
                        new GregorianCalendar(1969, Calendar.FEBRUARY, 11), 32));
                add(new ConcertTicket("Fleetwood Mac",
                        new GregorianCalendar(1975, Calendar.NOVEMBER, 11), 40));
                add(new ConcertTicket("Elvis Presley",
                        new GregorianCalendar(1956, Calendar.AUGUST, 11), 20));
                add(new ConcertTicket("The Clash",
                        new GregorianCalendar(1977, Calendar.MAY, 11), 20));
                add(new ConcertTicket("Nirvana",
                        new GregorianCalendar(1994, Calendar.AUGUST, 11), 80));
                add(new ConcertTicket("2Pac",
                        new GregorianCalendar(2018, Calendar.MARCH, 11), 25));
                add(new ConcertTicket("Smashing Pumpkins",
                        new GregorianCalendar(1996, Calendar.DECEMBER, 11), 30));
                add(new ConcertTicket("Less Than Jake",
                        new GregorianCalendar(2017, Calendar.OCTOBER, 24), 5));
            }
        };
        //</editor-fold>
        
        //HashTable with 30 slots
        HashTable<ConcertTicket> table = new HashTable<>(30);
        for (ConcertTicket t : tickets) {
            table.put(t.getHashKey(), t);
        }
        System.out.println("30 Slot Table");
        System.out.println(table.toString());
        
        //Same elements in a larger table
        table = new HashTable<>(50);
        for (ConcertTicket t : tickets) {
            table.put(t.getHashKey(), t);
        }
        System.out.println("50 Slot Table");
        System.out.println(table.toString());
    }

}
